// lambda/shared/ddb.js
'use strict';
const { DynamoDBClient }       = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient,
        GetCommand, PutCommand, UpdateCommand, DeleteCommand,
        QueryCommand, ScanCommand, BatchGetCommand }  = require('@aws-sdk/lib-dynamodb');

const raw = new DynamoDBClient({
  region: process.env.AWS_REGION || 'us-east-1',
  maxAttempts: 3,
});
const ddb = DynamoDBDocumentClient.from(raw, {
  marshallOptions:   { removeUndefinedValues: true },
  unmarshallOptions: { wrapNumbers: false },
});

const Tables = {
  LAYERS:        process.env.LAYERS_TABLE,
  VENDORS:       process.env.VENDORS_TABLE,
  DEMOS:         process.env.DEMOS_TABLE,
  COMPONENTS:    process.env.COMPONENTS_TABLE,
  VIDEOS:        process.env.VIDEOS_TABLE,
  DEPLOY_STATES: process.env.DEPLOY_STATES_TABLE,
};

// ── helpers ──────────────────────────────────────────────────────────────────
const ok    = (body, code = 200) => ({
  statusCode: code,
  headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
  body: JSON.stringify(body),
});
const err   = (msg, code = 500) => ({
  statusCode: code,
  headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
  body: JSON.stringify({ error: msg }),
});

// Scan an entire small table (layers, vendors — max 6 items, safe to scan)
async function scanAll(tableName) {
  const { Items = [] } = await ddb.send(new ScanCommand({ TableName: tableName }));
  return Items;
}

// Query by PK only (returns all SK values)
async function queryPK(tableName, pkName, pkValue, skPrefix = null) {
  const params = {
    TableName: tableName,
    KeyConditionExpression: skPrefix
      ? `${pkName} = :pk AND begins_with(sk, :skp)`
      : `${pkName} = :pk`,
    ExpressionAttributeValues: skPrefix
      ? { ':pk': pkValue, ':skp': skPrefix }
      : { ':pk': pkValue },
  };
  const { Items = [] } = await ddb.send(new QueryCommand(params));
  return Items;
}

// Query GSI
async function queryGSI(tableName, indexName, pkName, pkValue, skName = null, skValue = null) {
  const expr = skName
    ? `${pkName} = :pk AND ${skName} = :sk`
    : `${pkName} = :pk`;
  const vals = skName
    ? { ':pk': pkValue, ':sk': skValue }
    : { ':pk': pkValue };
  const { Items = [] } = await ddb.send(new QueryCommand({
    TableName: tableName,
    IndexName: indexName,
    KeyConditionExpression: expr,
    ExpressionAttributeValues: vals,
  }));
  return Items;
}

// Batch get deploy states for a list of component IDs
async function batchGetDeployStates(componentIds) {
  if (!componentIds.length) return {};
  const keys  = componentIds.map(id => ({ component_id: id }));
  const { Responses = {} } = await ddb.send(new BatchGetCommand({
    RequestItems: { [Tables.DEPLOY_STATES]: { Keys: keys } },
  }));
  const items = Responses[Tables.DEPLOY_STATES] || [];
  return Object.fromEntries(items.map(i => [i.component_id, i]));
}

module.exports = { ddb, Tables, ok, err, scanAll, queryPK, queryGSI, batchGetDeployStates,
  GetCommand, PutCommand, UpdateCommand, DeleteCommand, QueryCommand, ScanCommand };
