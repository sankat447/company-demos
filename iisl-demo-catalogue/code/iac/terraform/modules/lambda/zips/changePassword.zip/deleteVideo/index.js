// lambda/deleteVideo/index.js
// DELETE /demos/{demoId}/video/{videoId}
// Deletes video metadata from DynamoDB and the S3 object.

'use strict';
const { S3Client, DeleteObjectCommand } = require('@aws-sdk/client-s3');
const { ddb, Tables, ok, err, GetCommand } = require('../shared/ddb');
const { DeleteCommand } = require('@aws-sdk/lib-dynamodb');
const { requireAuth }   = require('../shared/auth');

const s3 = new S3Client({ region: process.env.AWS_REGION || 'us-east-1' });
const BUCKET = process.env.VIDEOS_BUCKET;

exports.handler = async (event) => {
  try { requireAuth(event); } catch (e) { return err(e.message, 401); }
  const demoId  = event.pathParameters?.demoId;
  const videoId = event.pathParameters?.videoId;

  if (!demoId || !videoId) return err('Missing demoId or videoId', 400);

  try {
    // 1. Get the record first to find the S3 key
    const { Item } = await ddb.send(new GetCommand({
      TableName: Tables.VIDEOS,
      Key: { demo_id: demoId, video_id: videoId },
    }));

    if (!Item) return err('Video not found', 404);

    // 2. Delete the S3 object
    if (Item.s3_key) {
      await s3.send(new DeleteObjectCommand({
        Bucket: BUCKET,
        Key: Item.s3_key,
      }));
    }

    // 3. Delete the DynamoDB record
    await ddb.send(new DeleteCommand({
      TableName: Tables.VIDEOS,
      Key: { demo_id: demoId, video_id: videoId },
    }));

    return ok({ deleted: true, demoId, videoId });
  } catch (e) {
    console.error('deleteVideo error:', e);
    return err(e.message);
  }
};
