// lambda/getComponents/index.js
// AP-07: GET /demos/{demoId}/components
// Returns all native + iisl components for a demo, with deploy states merged in
// from iisl_deploy_states.  This is the single call the React DemoCard makes
// when the user expands a demo row.

'use strict';
const { Tables, ok, err, queryPK, batchGetDeployStates } = require('../shared/ddb');
const { requireAuth }                                     = require('../shared/auth');

exports.handler = async (event) => {
  try {
    try { requireAuth(event); } catch (e) { return err(e.message, 401); }
    const demoId = event.pathParameters?.demoId || event.queryStringParameters?.demoId;
    if (!demoId) return err('demoId is required', 400);

    // Query all components for this demo (PK = demo_id, SK sorted NATIVE/IISL first)
    const raw = await queryPK(Tables.COMPONENTS, 'demo_id', demoId);
    raw.sort((a, b) => a.comp_sort_key.localeCompare(b.comp_sort_key));

    // Batch-fetch deploy states for all component IDs
    const componentIds = raw.map(c => c.component_id);
    const deployStates = await batchGetDeployStates(componentIds);

    // Merge deploy state into each component
    const components = raw.map(c => ({
      ...c,
      deployState: deployStates[c.component_id] || null,
      isDeployed:  !!(deployStates[c.component_id]?.status === 'deployed'
                   || c.status === 'D' || c.status === 'N'),
    }));

    const native = components.filter(c => c.comp_type === 'native');
    const iisl   = components.filter(c => c.comp_type === 'iisl');

    return ok({ demoId, native, iisl, total: components.length });

  } catch (e) {
    console.error('getComponents error:', e);
    return err(e.message);
  }
};
