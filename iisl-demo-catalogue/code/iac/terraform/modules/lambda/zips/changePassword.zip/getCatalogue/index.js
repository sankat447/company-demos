// lambda/getCatalogue/index.js
// AP-01: GET /catalogue  or  GET /layers  or  GET /vendors
// Returns all layers + all vendors in one response for the initial page load.
// The React app caches this and uses it for the sidebar and breadcrumbs.
// Subsequent drill-down calls use /demos?layerId=&vendorId= (getDemos function).

'use strict';
const { scanAll, Tables, ok, err } = require('../shared/ddb');
const { requireAuth }              = require('../shared/auth');

exports.handler = async (event) => {
  try {
    try { requireAuth(event); } catch (e) { return err(e.message, 401); }
    const path = event.rawPath || event.path || '';

    if (path.endsWith('/vendors')) {
      const vendors = await scanAll(Tables.VENDORS);
      vendors.sort((a, b) => (a.sort_order || 99) - (b.sort_order || 99));
      return ok({ vendors });
    }

    if (path.endsWith('/layers')) {
      const layers = await scanAll(Tables.LAYERS);
      layers.sort((a, b) => (a.sort_order || 99) - (b.sort_order || 99));
      return ok({ layers });
    }

    // Default /catalogue — return both
    const [layers, vendors] = await Promise.all([
      scanAll(Tables.LAYERS),
      scanAll(Tables.VENDORS),
    ]);
    layers.sort((a, b) => a.sort_order - b.sort_order);
    vendors.sort((a, b) => (a.sort_order || 99) - (b.sort_order || 99));
    return ok({ layers, vendors });

  } catch (e) {
    console.error('getCatalogue error:', e);
    return err(e.message);
  }
};
