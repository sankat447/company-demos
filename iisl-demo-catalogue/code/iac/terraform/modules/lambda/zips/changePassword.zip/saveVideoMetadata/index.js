// lambda/saveVideoMetadata/index.js
// POST /demos/{demoId}/video
// Body: { videoId, s3Key, title, durationSec?, fileSizeBytes?, thumbnailS3Key? }
// Called by the frontend immediately after a successful S3 PUT.
// Sets status to "ready" (no transcoding pipeline in this version;
// swap to "pending" and trigger MediaConvert for production transcoding).

'use strict';
const { S3Client, HeadObjectCommand } = require('@aws-sdk/client-s3');
const { ddb, Tables, ok, err, PutCommand } = require('../shared/ddb');
const { requireAuth }                      = require('../shared/auth');

const s3 = new S3Client({ region: process.env.AWS_REGION || 'us-east-1' });

exports.handler = async (event) => {
  try {
    try { requireAuth(event); } catch (e) { return err(e.message, 401); }
    const demoId = event.pathParameters?.demoId;
    if (!demoId) return err('demoId path param required', 400);

    const body  = JSON.parse(event.body || '{}');
    const { videoId, s3Key, title, durationSec, fileSizeBytes, thumbnailS3Key } = body;

    if (!videoId) return err('videoId is required', 400);
    if (!s3Key)   return err('s3Key is required', 400);

    // Verify the object actually exists in S3 (prevents fake metadata saves)
    let s3Meta = {};
    try {
      const head = await s3.send(new HeadObjectCommand({
        Bucket: process.env.VIDEOS_BUCKET,
        Key:    s3Key,
      }));
      s3Meta = {
        file_size_bytes: head.ContentLength,
        content_type:    head.ContentType,
      };
    } catch (headErr) {
      console.warn('S3 HeadObject failed (object may not exist yet):', headErr.message);
      // Don't fail — upload might be in-flight; client should retry
    }

    const cfDomain   = process.env.CLOUDFRONT_DOMAIN;
    const cf_url     = cfDomain ? `https://${cfDomain}/${s3Key}` : null;
    const uploadedAt = new Date().toISOString();

    const item = {
      demo_id:          demoId,
      video_id:         `VID#${videoId}`,
      title:            (title || `Demo recording ${new Date().toLocaleDateString()}`).slice(0, 256),
      s3_key:           s3Key,
      cf_url,
      thumbnail_s3_key: thumbnailS3Key || null,
      status:           'ready',
      duration_sec:     durationSec  ? Number(durationSec)  : null,
      file_size_bytes:  fileSizeBytes ? Number(fileSizeBytes) : s3Meta.file_size_bytes || null,
      content_type:     s3Meta.content_type || null,
      uploaded_at:      uploadedAt,
      uploaded_by:      event.requestContext?.authorizer?.claims?.email || 'anonymous',
    };

    await ddb.send(new PutCommand({ TableName: Tables.VIDEOS, Item: item }));

    return ok({ message: 'Video metadata saved', demoId, videoId, cf_url, status: 'ready' }, 201);

  } catch (e) {
    console.error('saveVideoMetadata error:', e);
    return err(e.message);
  }
};
