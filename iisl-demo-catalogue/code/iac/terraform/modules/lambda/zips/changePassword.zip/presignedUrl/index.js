// lambda/presignedUrl/index.js
// POST /videos/presigned-url
// Body: { demoId, fileName, contentType, title }
// Returns a presigned PUT URL valid for 15 minutes that the browser uses to
// upload the video file directly to S3 — the API never proxies the binary.
// After upload the client calls POST /demos/{demoId}/video to save metadata.

'use strict';
const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');
const { getSignedUrl }               = require('@aws-sdk/s3-request-presigner');
const { ok, err }                    = require('../shared/ddb');
const { requireAuth }                = require('../shared/auth');
const { randomUUID }                 = require('crypto');

const s3 = new S3Client({ region: process.env.AWS_REGION || 'us-east-1' });

const ALLOWED_TYPES  = ['video/mp4', 'video/webm', 'video/quicktime', 'video/x-msvideo'];
const MAX_SIZE_BYTES = 2 * 1024 * 1024 * 1024; // 2 GB

exports.handler = async (event) => {
  try {
    try { requireAuth(event); } catch (e) { return err(e.message, 401); }
    const body = JSON.parse(event.body || '{}');
    const { demoId, fileName, contentType, title } = body;

    if (!demoId)      return err('demoId is required', 400);
    if (!fileName)    return err('fileName is required', 400);
    if (!contentType) return err('contentType is required', 400);
    if (!ALLOWED_TYPES.includes(contentType))
      return err(`contentType must be one of: ${ALLOWED_TYPES.join(', ')}`, 400);

    const videoId = randomUUID();
    const ext     = fileName.split('.').pop().toLowerCase() || 'mp4';
    const s3Key   = `videos/${demoId}/${videoId}.${ext}`;
    const bucket  = process.env.VIDEOS_BUCKET;

    const command = new PutObjectCommand({
      Bucket:      bucket,
      Key:         s3Key,
      ContentType: contentType,
      Metadata: {
        'demo-id':   demoId,
        'video-id':  videoId,
        'title':     (title || '').slice(0, 256),
        'uploaded-by': event.requestContext?.authorizer?.claims?.email || 'anonymous',
      },
    });

    const presignedUrl = await getSignedUrl(s3, command, { expiresIn: 900 }); // 15 min

    return ok({
      uploadUrl:   presignedUrl,
      videoId,
      s3Key,
      bucket,
      expiresInSec: 900,
      instructions: 'PUT the video file to uploadUrl with the correct Content-Type header, then call POST /demos/{demoId}/video with the videoId to save metadata.',
    });

  } catch (e) {
    console.error('presignedUrl error:', e);
    return err(e.message);
  }
};
