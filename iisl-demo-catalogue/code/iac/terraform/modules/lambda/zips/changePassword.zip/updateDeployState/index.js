// lambda/updateDeployState/index.js
// PUT /components/{componentId}/deploy
// Body: { status: "deployed"|"pending"|"failed", notes?, deployedBy? }
// Upserts a record in iisl_deploy_states.
// The React DEPLOY SELECTED button calls this for each checked component.

'use strict';
const { ddb, Tables, ok, err, UpdateCommand } = require('../shared/ddb');
const { requireAuth }                         = require('../shared/auth');

const VALID_STATUSES = ['deployed', 'pending', 'failed', 'deploying'];

exports.handler = async (event) => {
  try {
    try { requireAuth(event); } catch (e) { return err(e.message, 401); }
    const componentId = event.pathParameters?.componentId;
    if (!componentId) return err('componentId path param required', 400);

    const body   = JSON.parse(event.body || '{}');
    const status = body.status || 'deployed';

    if (!VALID_STATUSES.includes(status))
      return err(`status must be one of: ${VALID_STATUSES.join(', ')}`, 400);

    const now         = new Date().toISOString();
    const deployedBy  = body.deployedBy
                     || event.requestContext?.authorizer?.claims?.email
                     || 'system';

    await ddb.send(new UpdateCommand({
      TableName:        Tables.DEPLOY_STATES,
      Key:              { component_id: componentId },
      UpdateExpression: `SET #s = :s, updated_at = :ua, deployed_by = :by
                         ${status === 'deployed' ? ', deployed_at = :da' : ''}
                         ${body.notes ? ', notes = :n' : ''}`,
      ExpressionAttributeNames:  { '#s': 'status' },
      ExpressionAttributeValues: {
        ':s':  status,
        ':ua': now,
        ':by': deployedBy,
        ...(status === 'deployed' ? { ':da': now }    : {}),
        ...(body.notes            ? { ':n': body.notes } : {}),
      },
      ReturnValues: 'ALL_NEW',
    }));

    return ok({ componentId, status, updatedAt: now, deployedBy });

  } catch (e) {
    console.error('updateDeployState error:', e);
    return err(e.message);
  }
};
