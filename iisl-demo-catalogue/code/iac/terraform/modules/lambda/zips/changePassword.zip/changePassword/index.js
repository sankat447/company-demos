// lambda/changePassword/index.js
// POST /change-password  body: { currentPassword, newPassword }
// Requires valid auth token. Validates current password, sets new one,
// and clears the force_password_change flag.

'use strict';
const { ddb, ok, err, GetCommand, UpdateCommand } = require('../shared/ddb');
const { requireAuth } = require('../shared/auth');

const USERS_TABLE = process.env.USERS_TABLE;

exports.handler = async (event) => {
  let claims;
  try { claims = requireAuth(event); } catch (e) { return err(e.message, 401); }

  let body;
  try { body = JSON.parse(event.body || '{}'); }
  catch { return err('Invalid JSON body', 400); }

  const { currentPassword, newPassword } = body;
  if (!currentPassword || !newPassword) return err('currentPassword and newPassword are required', 400);
  if (newPassword.length < 8) return err('New password must be at least 8 characters', 400);
  if (currentPassword === newPassword) return err('New password must be different from current password', 400);

  try {
    // Verify current password
    const { Item } = await ddb.send(new GetCommand({
      TableName: USERS_TABLE,
      Key: { email: claims.email },
    }));

    if (!Item) return err('User not found', 404);
    if (Item.password !== currentPassword) return err('Current password is incorrect', 401);

    // Update password and clear force_password_change flag
    await ddb.send(new UpdateCommand({
      TableName: USERS_TABLE,
      Key: { email: claims.email },
      UpdateExpression: 'SET #pw = :pw, #fpc = :fpc, #updated = :ts',
      ExpressionAttributeNames: {
        '#pw': 'password',
        '#fpc': 'force_password_change',
        '#updated': 'updated_at',
      },
      ExpressionAttributeValues: {
        ':pw': newPassword,
        ':fpc': false,
        ':ts': new Date().toISOString(),
      },
    }));

    return ok({ success: true, message: 'Password changed successfully' });
  } catch (e) {
    console.error('changePassword error:', e);
    return err(e.message);
  }
};
