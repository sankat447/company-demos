// lambda/getVideo/index.js
// AP-09: GET /demos/{demoId}/video
// Returns video metadata from iisl_videos.
// For "ready" videos, generates a time-limited CloudFront signed URL
// using the private key stored in SSM Parameter Store.

'use strict';
const { SSMClient, GetParameterCommand } = require('@aws-sdk/client-ssm');
const { getSignedUrl }                   = require('@aws-sdk/cloudfront-signer');
const { ddb, Tables, ok, err, QueryCommand } = require('../shared/ddb');
const { requireAuth }                        = require('../shared/auth');

const ssm = new SSMClient({ region: process.env.AWS_REGION || 'us-east-1' });
let _cachedKey = null;

async function getPrivateKey() {
  if (_cachedKey) return _cachedKey;
  const { Parameter } = await ssm.send(new GetParameterCommand({
    Name:           process.env.CLOUDFRONT_KEY_PARAM || '/iisl/cf-private-key',
    WithDecryption: true,
  }));
  _cachedKey = Parameter.Value;
  return _cachedKey;
}

exports.handler = async (event) => {
  try {
    try { requireAuth(event); } catch (e) { return err(e.message, 401); }
    const demoId = event.pathParameters?.demoId || event.queryStringParameters?.demoId;
    if (!demoId) return err('demoId is required', 400);

    // Fetch all videos for this demo (sorted by upload time, newest first)
    const { Items: videos = [] } = await ddb.send(new QueryCommand({
      TableName:                 Tables.VIDEOS,
      KeyConditionExpression:    'demo_id = :d',
      ExpressionAttributeValues: { ':d': demoId },
      ScanIndexForward:          false,   // newest first
    }));

    if (!videos.length) {
      return ok({ demoId, hasVideo: false, videos: [] });
    }

    // Generate a CloudFront signed URL for each "ready" video (1-hour expiry)
    const cfKeyId  = process.env.CLOUDFRONT_KEY_ID;
    const cfDomain = process.env.CLOUDFRONT_DOMAIN;
    const signed   = [];

    for (const v of videos) {
      if (v.status !== 'ready') {
        signed.push({ ...v, signedUrl: null });
        continue;
      }

      // If CloudFront key pair is configured, generate signed URLs
      if (cfKeyId && cfDomain) {
        try {
          const privateKey = await getPrivateKey();
          const url        = `https://${cfDomain}/${v.s3_key}`;
          const expiry     = new Date(Date.now() + 3600_000); // 1 hour
          const signedUrl  = getSignedUrl({ url, keyPairId: cfKeyId, privateKey, dateLessThan: expiry });
          signed.push({ ...v, signedUrl, expiresAt: expiry.toISOString() });
          continue;
        } catch (sigErr) {
          console.warn('CloudFront signing failed for', v.video_id, sigErr.message);
        }
      }

      // Fallback: use the cf_url directly (works when no trusted_key_groups on CF behavior)
      const directUrl = v.cf_url || (cfDomain ? `https://${cfDomain}/${v.s3_key}` : null);
      signed.push({ ...v, signedUrl: directUrl });
    }

    return ok({ demoId, hasVideo: true, videos: signed });

  } catch (e) {
    console.error('getVideo error:', e);
    return err(e.message);
  }
};
