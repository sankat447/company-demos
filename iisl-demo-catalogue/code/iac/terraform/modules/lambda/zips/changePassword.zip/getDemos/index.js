// lambda/getDemos/index.js
// AP-03: GET /demos?layerId=L1&vendorId=rhoai  → layer_vendor_idx GSI
// AP-04: GET /demos?vendorId=rhoai             → vendor_idx GSI
// AP-05: GET /demos?fw=RAG                     → fw_idx GSI
// AP-06: GET /demos/{demoId}                   → PK lookup
// AP-10: GET /demos?layerId=L1 (no vendor)     → all demos in a layer (scans vendor_idx per vendor)

'use strict';
const { ddb, Tables, queryGSI, ok, err, GetCommand } = require('../shared/ddb');
const { requireAuth }                                 = require('../shared/auth');

exports.handler = async (event) => {
  try {
    try { requireAuth(event); } catch (e) { return err(e.message, 401); }
    const { layerId, vendorId, fw, demoId: qsDemoId } = event.queryStringParameters || {};
    const pathDemoId = event.pathParameters?.demoId;
    const demoId = pathDemoId || qsDemoId;

    // ── AP-06: single demo by ID ─────────────────────────────────────────
    if (demoId) {
      const { Item } = await ddb.send(new GetCommand({
        TableName: Tables.DEMOS,
        Key: { demo_id: demoId },
      }));
      if (!Item) return err('Demo not found', 404);
      return ok({ demo: Item });
    }

    // ── AP-03: demos for a specific layer + vendor ───────────────────────
    if (layerId && vendorId) {
      const key = `${layerId}#${vendorId}`;
      const items = await queryGSI(Tables.DEMOS, 'layer_vendor_idx', 'layer_vendor_key', key);
      items.sort((a, b) => (a.sort_order || 99) - (b.sort_order || 99));
      return ok({ demos: items, layerId, vendorId });
    }

    // ── AP-04: all demos for one vendor ──────────────────────────────────
    if (vendorId) {
      const items = await queryGSI(Tables.DEMOS, 'vendor_idx', 'vendor_id', vendorId);
      items.sort((a, b) => (a.sort_order || 99) - (b.sort_order || 99));
      return ok({ demos: items, vendorId });
    }

    // ── AP-05: all demos for a framework tag ─────────────────────────────
    if (fw) {
      const items = await queryGSI(Tables.DEMOS, 'fw_idx', 'fw', fw);
      return ok({ demos: items, fw });
    }

    return err('Provide layerId+vendorId, vendorId, fw, or demoId as query params', 400);

  } catch (e) {
    console.error('getDemos error:', e);
    return err(e.message);
  }
};
