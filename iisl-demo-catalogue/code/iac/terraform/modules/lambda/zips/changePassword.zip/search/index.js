// lambda/search/index.js
// GET /search?q=DCIM&limit=20&vendorId=rhoai
// Performs a DynamoDB FilterExpression scan on the demos table then fetches
// matching component names.  For catalogue sizes (<500 demos) this is fast
// enough.  For larger catalogues swap the scan for an OpenSearch integration.

'use strict';
const { ddb, Tables, ok, err, ScanCommand, QueryCommand } = require('../shared/ddb');
const { requireAuth }                                     = require('../shared/auth');

const MAX_RESULTS = 50;

exports.handler = async (event) => {
  try {
    try { requireAuth(event); } catch (e) { return err(e.message, 401); }
    const qs       = event.queryStringParameters || {};
    const q        = (qs.q || '').trim().toLowerCase();
    const vendorId = qs.vendorId || null;
    const limit    = Math.min(parseInt(qs.limit || '20', 10), MAX_RESULTS);

    if (!q || q.length < 2) return err('q must be at least 2 characters', 400);

    // ── 1. Scan demos table with filter ─────────────────────────────────
    const scanParams = {
      TableName:        Tables.DEMOS,
      FilterExpression: `contains(#nm, :q) OR contains(description, :q) OR contains(fw, :q)`,
      ExpressionAttributeNames:  { '#nm': 'name' },
      ExpressionAttributeValues: { ':q': q },
    };
    if (vendorId) {
      scanParams.FilterExpression += ' AND vendor_id = :v';
      scanParams.ExpressionAttributeValues[':v'] = vendorId;
    }

    const { Items: demoMatches = [] } = await ddb.send(new ScanCommand(scanParams));

    // ── 2. Scan components table for keyword matches ──────────────────────
    const { Items: compMatches = [] } = await ddb.send(new ScanCommand({
      TableName:        Tables.COMPONENTS,
      FilterExpression: 'contains(#nm, :q)',
      ExpressionAttributeNames:  { '#nm': 'name' },
      ExpressionAttributeValues: { ':q': q },
      ProjectionExpression: 'demo_id, component_id, #nm, comp_type, #st',
      ExpressionAttributeNames: { '#nm': 'name', '#st': 'status' },
    }));

    // Group component matches by demo_id so the frontend can highlight them
    const compsByDemo = {};
    for (const c of compMatches) {
      if (!compsByDemo[c.demo_id]) compsByDemo[c.demo_id] = [];
      compsByDemo[c.demo_id].push(c);
    }

    // Fetch the demo records for component-matched demos not already in demoMatches
    const demoIds        = new Set(demoMatches.map(d => d.demo_id));
    const compDemoIds    = Object.keys(compsByDemo).filter(id => !demoIds.has(id));
    let   additionalDemo = [];
    if (compDemoIds.length) {
      const fetched = await Promise.all(
        compDemoIds.map(id => ddb.send(new QueryCommand({
          TableName:                 Tables.DEMOS,
          KeyConditionExpression:    'demo_id = :d',
          ExpressionAttributeValues: { ':d': id },
        })).then(r => r.Items?.[0]).catch(() => null))
      );
      additionalDemo = fetched.filter(Boolean);
    }

    const allDemos = [...demoMatches, ...additionalDemo];
    // Annotate with matched components and sort by relevance (name match > desc match)
    const results = allDemos
      .slice(0, limit)
      .map(demo => ({
        ...demo,
        matchedComponents: compsByDemo[demo.demo_id] || [],
        nameMatch: demo.name.toLowerCase().includes(q),
      }))
      .sort((a, b) => (b.nameMatch ? 1 : 0) - (a.nameMatch ? 1 : 0));

    return ok({
      query: q,
      total: results.length,
      demos: results,
    });

  } catch (e) {
    console.error('search error:', e);
    return err(e.message);
  }
};
