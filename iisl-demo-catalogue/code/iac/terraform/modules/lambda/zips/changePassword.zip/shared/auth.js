// lambda/shared/auth.js
// HMAC-signed bearer-token auth helpers for IISL Catalogue lambdas.
// Token format: base64url(JSON.stringify({email, exp})) + "." + hex(HMAC-SHA256(payload, AUTH_SECRET))
'use strict';
const crypto = require('crypto');

function b64urlEncode(buf) {
  return Buffer.from(buf).toString('base64')
    .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function b64urlDecode(str) {
  const pad = str.length % 4 === 0 ? '' : '='.repeat(4 - (str.length % 4));
  return Buffer.from(str.replace(/-/g, '+').replace(/_/g, '/') + pad, 'base64').toString('utf8');
}

function hmac(payload) {
  const secret = process.env.AUTH_SECRET || '';
  if (!secret) throw new Error('AUTH_SECRET not configured');
  return crypto.createHmac('sha256', secret).update(payload).digest('hex');
}

function signToken(claims, ttlSec = 8 * 3600) {
  const body    = { ...claims, exp: Math.floor(Date.now() / 1000) + ttlSec };
  const payload = b64urlEncode(JSON.stringify(body));
  return `${payload}.${hmac(payload)}`;
}

function verifyToken(authHeader) {
  if (!authHeader || typeof authHeader !== 'string') throw new Error('Missing Authorization header');
  const m = authHeader.match(/^Bearer\s+(.+)$/i);
  if (!m) throw new Error('Invalid Authorization header format');
  const token = m[1];
  const parts = token.split('.');
  if (parts.length !== 2) throw new Error('Malformed token');
  const [payload, sig] = parts;
  const expected = hmac(payload);
  // constant-time comparison
  const a = Buffer.from(sig, 'hex');
  const b = Buffer.from(expected, 'hex');
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) throw new Error('Invalid token signature');
  let body;
  try { body = JSON.parse(b64urlDecode(payload)); } catch { throw new Error('Invalid token payload'); }
  if (!body.exp || Math.floor(Date.now() / 1000) > body.exp) throw new Error('Token expired');
  if (!body.email) throw new Error('Token missing email claim');
  return { email: body.email };
}

function headerLookup(headers, name) {
  if (!headers) return null;
  const want = name.toLowerCase();
  for (const k of Object.keys(headers)) {
    if (k.toLowerCase() === want) return headers[k];
  }
  return null;
}

function requireAuth(event) {
  const auth = headerLookup(event && event.headers, 'authorization');
  return verifyToken(auth);
}

module.exports = { signToken, verifyToken, requireAuth };
