// lambda/updateVideoMetadata/index.js
// PUT /demos/{demoId}/video/{videoId}
// Updates mutable video metadata fields (title, status, description).
// Does NOT touch S3 — metadata only.

'use strict';
const { ddb, Tables, ok, err, UpdateCommand } = require('../shared/ddb');
const { requireAuth }                         = require('../shared/auth');

exports.handler = async (event) => {
  try { requireAuth(event); } catch (e) { return err(e.message, 401); }
  const demoId  = event.pathParameters?.demoId;
  const videoId = event.pathParameters?.videoId;

  if (!demoId || !videoId) return err('Missing demoId or videoId', 400);

  let body;
  try {
    body = JSON.parse(event.body || '{}');
  } catch {
    return err('Invalid JSON body', 400);
  }

  // Build update expression from allowed fields
  const allowed = ['title', 'status', 'description'];
  const updates = {};
  for (const key of allowed) {
    if (body[key] !== undefined) updates[key] = body[key];
  }

  if (!Object.keys(updates).length) return err('No valid fields to update (allowed: title, status, description)', 400);

  // Always set updated_at
  updates.updated_at = new Date().toISOString();

  const exprParts = [];
  const names = {};
  const values = {};

  for (const [key, val] of Object.entries(updates)) {
    const nameToken = `#${key}`;
    const valToken  = `:${key}`;
    exprParts.push(`${nameToken} = ${valToken}`);
    names[nameToken] = key;
    values[valToken] = val;
  }

  try {
    const { Attributes } = await ddb.send(new UpdateCommand({
      TableName: Tables.VIDEOS,
      Key: { demo_id: demoId, video_id: videoId },
      UpdateExpression: `SET ${exprParts.join(', ')}`,
      ExpressionAttributeNames: names,
      ExpressionAttributeValues: values,
      ReturnValues: 'ALL_NEW',
    }));

    return ok(Attributes);
  } catch (e) {
    console.error('updateVideoMetadata error:', e);
    return err(e.message);
  }
};
