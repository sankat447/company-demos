// lambda/login/index.js
// POST /login  body: { email, password }
// Looks up user in USERS_TABLE by email PK, compares plain-text password
// (demo-only, by explicit request), and returns a HMAC-signed session token.
// If user has force_password_change=true, includes that flag in the response
// so the frontend can redirect to the change-password page.

'use strict';
const { ddb, ok, err, GetCommand } = require('../shared/ddb');
const { signToken }                = require('../shared/auth');

const USERS_TABLE = process.env.USERS_TABLE;

exports.handler = async (event) => {
  try {
    let body;
    try { body = JSON.parse(event.body || '{}'); }
    catch { return err('Invalid JSON body', 400); }

    const email    = (body.email || '').trim().toLowerCase();
    const password = body.password || '';

    if (!email || !password) return err('email and password are required', 400);

    const { Item } = await ddb.send(new GetCommand({
      TableName: USERS_TABLE,
      Key:       { email },
    }));

    if (!Item || Item.password !== password) {
      return err('Invalid credentials', 401);
    }

    const token = signToken({ email });
    return ok({
      token,
      email,
      name: Item.name || '',
      force_password_change: Item.force_password_change === true,
    });

  } catch (e) {
    console.error('login error:', e);
    return err(e.message);
  }
};
